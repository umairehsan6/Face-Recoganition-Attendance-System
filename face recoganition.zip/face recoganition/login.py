from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector
import random
import time
from main import Face_Recognition_system


def main():
    win=Tk()
    app=Login_Window(win)
    win.mainloop()


class Login_Window:
    def __init__(self, root):
        self.root = root
        self.root.title("Facial Recoganition Attendence System-Login")
        self.root.geometry("1550x800+0+0")  # Corrected the geometry format

        # Load the background image
        self.bg = ImageTk.PhotoImage(file=r"images\college_images\1714682989911.jpg")
        lbl_bg = Label(self.root, image=self.bg)
        lbl_bg.place(x=0, y=0, relwidth=1, relheight=1)

        # Login Frame
        frame = Frame(self.root, bg="#003849")
        frame.place(x=100, y=170, width=340, height=450)
        

        # Load and resize user image
        img1 = Image.open(r"images\college_images\user-286.png")
        img1 = img1.resize((100, 100),)
        self.photoimage1 = ImageTk.PhotoImage(img1)
        lblimg1 = Label(image=self.photoimage1, bg="#003849", borderwidth=0)
        lblimg1.place(x=215, y=175, width=100, height=100)

        get_str=Label(frame,text="Get Started",font=("times new roman",20,"bold"),fg="white",bg="#003849")
        get_str.place(x=95,y=100)   

        #Label
        username=lbl=Label(frame,text="Username",font=("times new roman",15,"bold"),fg="white", bg="#003849")
        username.place(x=40,y=155)
        self.txtuser=ttk.Entry(frame,font=("times new roman",15,"bold"))
        self.txtuser.place(x=40,y=180,width=270)
        password=lbl=Label(frame,text="Password",font=("times new roman",15,"bold"),fg="white", bg="#003849")
        password.place(x=40,y=225)
        self.txtpass=ttk.Entry(frame,font=("times new roman",15,"bold"))
        self.txtpass.place(x=40,y=250,width=270)
        #Icon Images Username
        img2 = Image.open(r"images\college_images\user-286.png")
        img2 = img2.resize((25, 27),)
        self.photoimage2 = ImageTk.PhotoImage(img2)
        lblimg1 = Label(image=self.photoimage2, bg="#003849", borderwidth=0)
        lblimg1.place(x=115, y=325, width=25, height=27)
        #Icon Images Password
        img3 = Image.open(r"images\college_images\2344160.png")
        img3 = img3.resize((25, 27),)
        self.photoimage3 = ImageTk.PhotoImage(img3)
        lblimg1 = Label(image=self.photoimage3, bg="#003849", borderwidth=0)
        lblimg1.place(x=115, y=395, width=25, height=27)
        #Login Button
        loginbtn=Button(frame,command=self.login,text="Login",font=("times new roman",15,"bold"),bd=3,relief=RIDGE,fg="white",bg="#3282F0",activeforeground="White",activebackground="blue")
        loginbtn.place(x=110,y=300,width=120,height=35) 
        #Forget Button
        forgetbtn=Button(frame,text="Forget Password?",command=self.forgot_password_window, font=("times new roman",10,"bold"),borderwidth=0,fg="white",bg="#003849",activeforeground="White",activebackground="#003849")
        forgetbtn.place(x=180,y=380,width=160) 
        #New user registration
        registrationbtn=Button(frame,text="Sign Up",command=self.register_window,font=("times new roman",10,"bold"),borderwidth=0,fg="white",bg="#003849",activeforeground="White",activebackground="#003849")
        registrationbtn.place(x=-23,y=380,width=170)
        #To call Registration window on top
    def register_window(self):
        self.new_window=Toplevel(self.root) 
        self.app=Register(self.new_window)
    def login(self):
        if self.txtuser.get()==""or self.txtpass.get()=="":
            messagebox.showerror("error","all fields are required")
        elif self.txtuser.get()=="umair" and self.txtpass.get()=="ehsan":
            messagebox.showinfo("Success","Welcome To The Portal")
        else:
           conn=mysql.connector.connect(host="localhost",user="root",password="2072002",database="data")
           my_cursor=conn.cursor()
           my_cursor.execute("select * from register where email=%s and password=%s",(
                                                                                      self.txtuser.get(),
                                                                                      self.txtpass.get()
                 
                                                                                    ))
           row=my_cursor.fetchone()
           if row==None:
               messagebox.showerror("Error","Invalid data")
           else:
               open_main=messagebox.askyesno("YesNo","Access only admin")
               if open_main>0:
                   self.new_window=Toplevel(self.root)
                   # add the next program class to run after the login
                   self.app=Face_Recognition_system(self.new_window)
               else:
                   if not open_main:
                       return
           conn.commit()
           conn.close()
           
    #reset password function
    def reset_pass(self):
        if self.combo_security_Q.get()=="Select":
            messagebox.showerror("Error","Select Security Question")
        elif self.txt_security_A.get()=="":
            messagebox.showerror("Error","Please enter the answer")
        elif self.txt_newpass.get()=="":
             messagebox.showerror("Error","please enter the new Password")
        else:
            conn=mysql.connector.connect(host="localhost",user="root",password="2072002",database="data")
            my_cursor=conn.cursor()
            qury=("select * from register where email=%s and security_Q=%s and security_A=%s")
            vlaue=(self.txtuser.get(),self.combo_security_Q.get(),self.txt_security_A.get(),)
            my_cursor.execute(qury,vlaue)
            row=my_cursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Wrong Answer")
            else:
                query=("update register set password=%s where email=%s")
                value=(self.txt_newpass.get(),self.txtuser.get())
                my_cursor.execute(query,value)
                conn.commit()
                conn.close()
                messagebox.showinfo("Info","Your Password Has been reset to")
           #forgot password window
    def forgot_password_window(self):
        if self.txtuser.get()=="":
            messagebox.showerror("Error","Please Enter The Email To Reset The Password")
        else:
            conn=mysql.connector.connect(host="localhost",user="root",password="2072002",database="data")
            my_cursor=conn.cursor()
            query=("select * from register where email=%s")
            value=(self.txtuser.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            print(row)
            if row==None:
                messagebox.showerror("Error","Please Enter the Valid Email")
            else:
                conn.close()
                self.root2=Toplevel()
                self.root2.title("FRAS-Forget Password")
                self.root2.geometry("340x450+100+170")
                self.root2.configure(bg="#003849")

                l=Label(self.root2,text="Forget Password",font=("times new roman",20,"bold"),fg="white", bg="#003849")
                l.place(x=0,y=40,relwidth=1)

                security_Q = Label(self.root2, text="Security Question", font=("times new roman", 14, "bold"),fg="white", bg="#003849")
                security_Q.place(x=50, y=100)

                self.combo_security_Q = ttk.Combobox(self.root2,font=("times new roman", 14, "bold"),state="readonly")
                self.combo_security_Q["values"] = ("Select", "Your Birth Place", "Your Pet Name", "Your Bestfriend Name")
                self.combo_security_Q.place(x=50, y=130, width=250)
                self.combo_security_Q.current(0)

                security_A=Label(self.root2,text="Security Answer",font=("times new roman",14,"bold"),fg="white",bg="#003849")
                security_A.place(x=50,y=175)
                self.txt_security_A=ttk.Entry(self.root2,font=("times new roman",14,"bold"))
                self.txt_security_A.place(x=50,y=200,width=250)

                new_password=Label(self.root2,text="New Password",font=("times new roman",14,"bold"),fg="white",bg="#003849")
                new_password.place(x=50,y=240)
                self.txt_newpass=ttk.Entry(self.root2,font=("times new roman",14,"bold"))
                self.txt_newpass.place(x=50,y=270,width=250)

                btn=Button(self.root2,text="Reset" ,font=("times new roman",15,"bold"), fg="white" , bg="#3282F0",command=self.reset_pass)
                btn.place(x=125,y=350)


        
                

        
class Register:
    def __init__(self,root):
        self.root=root
        self.root.title("FRAS-Register")
        self.root.geometry("1550x840+0+0")
        #Variables
        self.var_fname=StringVar()
        self.var_l_name=StringVar()
        self.var_contact=StringVar()
        self.var_email=StringVar()
        self.var_security_Q=StringVar()
        self.var_security_A=StringVar()
        self.var_password=StringVar()
        self.var_password1=StringVar()
#Background Image
        self.bg=ImageTk.PhotoImage(file=r"images\college_images\banner-gm-apply-min.png")
        bg_lbl=Label(self.root,image=self.bg)
        bg_lbl.place(x=0,y=0,relwidth=1,relheight=1)

#main Frame
        frame=Frame(self.root,bg="#003849")
        frame.place(x=330,y=127,width=800,height=520)

        register_lbl=Label(frame,text="Register Here",font=("times new roman",20,"bold"),fg="white",bg="#003849")
        register_lbl.place(x=305,y=20)
#Label and entry
        fname=Label(frame,text="First Name",font=("times new roman",14,"bold"),fg="white",bg="#003849")
        fname.place(x=110,y=100)
        self.fname_entry=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",14,"bold"))
        self.fname_entry.place(x=110,y=130,width=250)

        l_name=Label(frame,text="Last Name",font=("times new roman",14,"bold"),fg="white",bg="#003849")
        l_name.place(x=430,y=100)
        self.txt_l_name=ttk.Entry(frame,textvariable=self.var_l_name,font=("times new roman",14,"bold"))
        self.txt_l_name.place(x=430,y=130,width=250)

        contact=Label(frame,text="Contact Number",font=("times new roman",14,"bold"),fg="white",bg="#003849")
        contact.place(x=110,y=170)
        self.txt_contact=ttk.Entry(frame,textvariable=self.var_contact,font=("times new roman",14,"bold"))
        self.txt_contact.place(x=110,y=200,width=250)
        
        email=Label(frame,text="Email",font=("times new roman",14,"bold"),fg="white",bg="#003849")
        email.place(x=430,y=170)
        self.txt_email=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",14,"bold"))
        self.txt_email.place(x=430,y=200,width=250)

        security_Q = Label(frame, text="Security Question", font=("times new roman", 14, "bold"),fg="white", bg="#003849")
        security_Q.place(x=110, y=240)

        self.combo_security_Q = ttk.Combobox(frame,textvariable=self.var_security_Q, font=("times new roman", 14, "bold"),state="readonly")
        self.combo_security_Q["values"] = ("Select", "Your Birth Place", "Your Pet Name", "Your Bestfriend Name")
        self.combo_security_Q.place(x=110, y=270, width=250)
        self.combo_security_Q.current(0)

        security_A=Label(frame,text="Security Answer",font=("times new roman",14,"bold"),fg="white",bg="#003849")
        security_A.place(x=430,y=240)
        self.txt_security_A=ttk.Entry(frame,textvariable=self.var_security_A,font=("times new roman",14,"bold"))
        self.txt_security_A.place(x=430,y=270,width=250)


        password=Label(frame,text="Password",font=("times new roman",14,"bold"),fg="white",bg="#003849")
        password.place(x=110,y=320)
        self.pass_password=ttk.Entry(frame,textvariable=self.var_password,font=("times new roman",14,"bold"))
        self.pass_password.place(x=110,y=350,width=250)
        
        password1=Label(frame,text="Confirm Password",font=("times new roman",14,"bold"),fg="white",bg="#003849")
        password1.place(x=430,y=320)
        self.pass_password1=ttk.Entry(frame,textvariable=self.var_password1,font=("times new roman",14,"bold"))
        self.pass_password1.place(x=430,y=350,width=250)
        #Buttons
        loginbtn=Button(frame,command=self.register_data,text="Register Now",font=("times new roman",15,"bold"),bd=2,relief=RIDGE,fg="white",bg="#3282F0",activeforeground="White",activebackground="blue")
        loginbtn.place(x=337,y=450,width=120,height=35) 
    

    def register_data(self):
        if self.var_fname.get()==""or self.var_email.get()==""or self.var_security_Q.get()=="Select":
            messagebox.showerror("Error","All Fields Are Required")
        elif self.var_password.get() != self.var_password1.get():
            messagebox.showerror("Error","Confirmation Password Isnt the same")
        elif len(self.var_password.get()) <8:
            messagebox.showerror("Error","The Length of password cant be less than 8")
        else:
           conn=mysql.connector.connect(host="localhost",user="root",password="2072002",database="data")
           my_cursor=conn.cursor()
           query=("select * from register where email=%s")
           value=(self.var_email.get(),)
           my_cursor.execute(query,value)
           row=my_cursor.fetchone()
           if row!=None:
               messagebox.showerror("Error","User already exist,Please Try Another Email")
           else:
               my_cursor.execute("insert into register values(%s,%s,%s,%s,%s,%s,%s,%s)",(
                                                                                        self.var_fname.get(),
                                                                                        self.var_l_name.get(),
                                                                                        self.var_email.get(),
                                                                                        self.var_contact.get(),
                                                                                        self.var_security_Q.get(),
                                                                                        self.var_security_A.get(),
                                                                                        self.var_password.get(),
                                                                                        self.var_password1.get()
                   
                                                                                     ))
           conn.commit()
           conn.close()
           messagebox.showinfo("Success","Registered Successful")


if __name__ == "__main__":
    main()