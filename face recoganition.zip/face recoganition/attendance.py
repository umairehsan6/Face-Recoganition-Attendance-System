from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector
from time import strftime
from datetime import datetime
import cv2
import os
import csv
from tkinter import filedialog
import numpy as np

mydata=[]
class Attendance:
    
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")   
        self.root.title("FRAS-Attendence Portal")
        
        
        
        #========variable=======
        self.var_student_id=StringVar()
        self.var_name=StringVar()
        self.var_roll=StringVar()
        self.var_dep=StringVar()
        self.var_time=StringVar()
        self.var_date=StringVar()
        self.var_atendance=StringVar()        
          # bg imag
        img3=Image.open(r"images\college_images\banner-gm-apply-min.png")
        img3=img3.resize((1530,800),)
        self.photoimg3=ImageTk.PhotoImage(img3)

        bg_img=Label(self.root,image=self.photoimg3)
        bg_img.place(x=0,y=0,width=1530,height=800)
        
        title_lbl=Label(bg_img,text= "Attendence Portal",font=("times new roman",35,"bold"),bg="#003849",fg="white") 
        title_lbl.place(x=20,y=81,width=1480,height=45)
        
        back_btn = Button(title_lbl, text="Back", command=self.back, font=("times new roman", 14 , "bold"), bg="red", fg="white")
        back_btn.place(x=1370, y=10, width=100,height=30)
    
    
        main_frame=Frame(bg_img,bd=2,bg="#003849")
        main_frame.place(x=20,y=125,width=1480,height=600)# Back Button
        
         
         #left label frame
        Left_frame=LabelFrame(main_frame,bd=2,bg="#003849",relief=RIDGE,text="Attendance Details",font=("times new roman",12,"bold"),fg="white")
        Left_frame.place(x=10,y=40,width=720,height=510)
        
        #  imag
        img_left=Image.open(r"images\college_images\1714711539358.jpg")
        img_left=img_left.resize((1550,800),)
        self.photoimg_left=ImageTk.PhotoImage(img_left)

        f_lbl=Label(Left_frame,image=self.photoimg_left)
        f_lbl.place(x=8,y=0,width=700,height=130)
        
        left_inside_frame=Frame(Left_frame,bd=2,relief=RIDGE,bg="#003849")
        left_inside_frame.place(x=8,y=140,width=700,height=350)
        
        
        
        # student id
        attendanceId_label=Label(left_inside_frame,text="StudentID:",font=("times new roman",12,"bold"),bg="#003849" ,fg="white")
        attendanceId_label.grid(row=0,column=0,padx=10,pady=5,sticky=W)

        attendanceID_entry=ttk.Entry(left_inside_frame,width=20,textvariable=self.var_student_id,font=("times new roman",12,"bold"))
        attendanceID_entry.grid(row=0,column=1,padx=10,pady=5,sticky=W)
        
        # name
        name_label=Label(left_inside_frame,text="Name:",font=("times new roman",12,"bold"),bg="#003849" ,fg="white")
        name_label.grid(row=0,column=2,padx=4,pady=8)

        atten_entry=ttk.Entry(left_inside_frame,width=20,textvariable=self.var_name,font=("times new roman",12,"bold"))
        atten_entry.grid(row=0,column=3,pady=8)
        
        # roll
        roll_label=Label(left_inside_frame,text="Roll_No:",font=("times new roman",12,"bold"),bg="#003849" ,fg="white")
        roll_label.grid(row=1,column=0)

        atten_entry=ttk.Entry(left_inside_frame,width=20,textvariable=self.var_roll,font=("times new roman",12,"bold"))
        atten_entry.grid(row=1,column=1,pady=8)
        
        # Dep
        dep_label=Label(left_inside_frame,text="Department:",font=("times new roman",12,"bold"),bg="#003849" ,fg="white")
        dep_label.grid(row=1,column=2)

        atten_entry=ttk.Entry(left_inside_frame,width=20,textvariable=self.var_dep,font=("times new roman",12,"bold"))
        atten_entry.grid(row=1,column=3,pady=8)
        
        
         
        # time
        time_label=Label(left_inside_frame,text="Time:",font=("times new roman",12,"bold"),bg="#003849" ,fg="white")
        time_label.grid(row=2,column=0)

        atten_entry=ttk.Entry(left_inside_frame,width=20,textvariable=self.var_time,font=("times new roman",12,"bold"))
        atten_entry.grid(row=2,column=1,pady=8)
        
        
         
        # Date
        date_label=Label(left_inside_frame,text="Date:",font=("times new roman",12,"bold"),bg="#003849" ,fg="white")
        date_label.grid(row=2,column=2)

        atten_entry=ttk.Entry(left_inside_frame,width=20,textvariable=self.var_date,font=("times new roman",12,"bold"))
        atten_entry.grid(row=2,column=3,pady=8)
        
        
        
         
        # attendance
        attendance_label=Label(left_inside_frame,text="Attendance Status:",font=("times new roman",12,"bold"),bg="#003849" ,fg="white")
        attendance_label.grid(row=3,column=0)
        
        self.attendance_status=ttk.Combobox(left_inside_frame,width=18,textvariable=self.var_atendance,font="comicsansns 11 bold",state="readonly")
        self.attendance_status["values"]=("Status","Present","Absent")
        self.attendance_status.grid(row=3,column=1,pady=8)
        self.attendance_status.current(0)
        # Buttons Frame
        bt_frame=Frame(left_inside_frame,bd=2,relief=RIDGE,bg="#003849")
        bt_frame.place(x=0,y=300,width=715,height=35)

        save_bt=Button(bt_frame,text="Import csv",command=self.importCsv,width=17,font=("times new roman",13,"bold"),bg="#3282F0",fg="white")
        save_bt.grid(row=0,column=0)

        update_bt=Button(bt_frame,text="Export csv",command=self.exportCsv,width=17,font=("times new roman",13,"bold"),bg="#3282F0",fg="white")
        update_bt.grid(row=0,column=1)

        delete_bt=Button(bt_frame,text="Update",width=17,font=("times new roman",13,"bold"),bg="#3282F0",fg="white")
        delete_bt.grid(row=0,column=2)

        reset_bt=Button(bt_frame,text="Reset",width=17,command=self.reset_data,font=("times new roman",13,"bold"),bg="#3282F0",fg="white")
        reset_bt.grid(row=0,column=3)
    
         #Right label frame
        Right_frame=LabelFrame(main_frame,bd=2,bg="#003849",relief=RIDGE,text="Attendance Details",font=("times new roman",12,"bold"),fg="white")
        Right_frame.place(x=750,y=40,width=720,height=510) 
        # Buttons Frame
        table_frame=Frame(Right_frame,bd=2,relief=RIDGE,bg="#003849")
        table_frame.place(x=5,y=5,width=705,height=477)
        
        #===========scroll bat table==========
        scroll_x=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(table_frame,orient=VERTICAL)
        
        
        self.AttendanceReportTable=ttk.Treeview(table_frame,column=("Studentid","Roll","Name","Department","Time","Date","Attendance"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)
        
        
        scroll_x.config(command=self.AttendanceReportTable.xview)
        scroll_y.config(command=self.AttendanceReportTable.yview)
        
        
        self.AttendanceReportTable.heading("Studentid",text="Student_ID")
        self.AttendanceReportTable.heading("Roll",text="Roll_No")
        self.AttendanceReportTable.heading("Name",text="Name")
        self.AttendanceReportTable.heading("Department",text="Department")
        self.AttendanceReportTable.heading("Time",text="Time")
        self.AttendanceReportTable.heading("Date",text="Date")
        self.AttendanceReportTable.heading("Attendance",text="Attendance")
        
        
        self.AttendanceReportTable["show"]="headings"
        self.AttendanceReportTable.column("Studentid",width=100)
        self.AttendanceReportTable.column("Roll",width=100)
        self.AttendanceReportTable.column("Name",width=100)
        self.AttendanceReportTable.column("Department",width=100)
        self.AttendanceReportTable.column("Time",width=100)
        self.AttendanceReportTable.column("Date",width=100)
        self.AttendanceReportTable.column("Attendance",width=100)
        
        
        
        
        
        self.AttendanceReportTable.pack(fill=BOTH,expand=1)
        self.AttendanceReportTable.bind("<ButtonRelease>",self.get_cursor)
         
    
        
    def back(self):
        self.root.destroy()
        import main    
        
        
        #=============fetch data=============
    def fetchData(self,rows):
      self.AttendanceReportTable.delete(*self.AttendanceReportTable.get_children())
      for i in rows:
        self.AttendanceReportTable.insert("",END,values=i)  
        
        
    def importCsv(self):    
      global mydata
      mydata.clear()
      fin=filedialog.askopenfilename(initialdir=os.getcwd(),title="Open CSV",filetypes=(("CV File","*.csv"),("All File","*.*")),parent=self.root)
      with open(fin) as myfile:
        csvread=csv.reader(myfile,delimiter=",")
        for i in csvread:
          mydata.append(i)
        self.fetchData(mydata)  
        
        
    def exportCsv(self):
      try:
        if len(mydata)<1:
          messagebox.showerror("No Data","No data found",parent=self.root)
          return False
        fin=filedialog.asksaveasfilename(initialdir=os.getcwd(),title="Open CSV",filetypes=(("CV File","*.csv"),("All File","*.*")),parent=self.root)
        with open(fin,mode="w",newline="") as myfile:
          exp_write=csv.writer(myfile,delimiter=",")
          for i in mydata:
            exp_write.writerow(i)
          messagebox.showinfo("Data Export"," Your data exported successfully to"+os.path.basename(fin)+"successfully")
      except Exception as es:
               messagebox.showerror("Error",f"Due To :{str(es)}",parent=self.root)   
                       
        
    def get_cursor(self,event=""):
      cursor_row=self.AttendanceReportTable.focus()
      content=self.AttendanceReportTable.item(cursor_row)
      rows=content['values']
      self.var_student_id.set(rows[0])
      self.var_roll.set(rows[1])
      self.var_name.set(rows[2])
      self.var_dep.set(rows[3])
      self.var_time.set(rows[4])
      self.var_date.set(rows[5]) 
      self.var_atendance.set(rows[6]) 
    
    def reset_data(self):  
      self.var_student_id.set(" ")
      self.var_roll.set(" ")
      self.var_name.set(" ")
      self.var_dep.set(" ")
      self.var_time.set(" ")
      self.var_date.set(" ") 
      self.var_atendance.set(" ")

        
        
        
if __name__=="__main__":
    root=Tk()
    obj=Attendance(root)
    root.mainloop()