from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk #pip install pillow


class ChatBot:
    def __init__(self,root):
        self.root=root
        self.root.title("ChatBot")
        self.root.geometry("730x620+0+0")
        self.root.bind("<Return>",self.enter_func)
        
        
        main_frame=Frame(self.root,bd=4,bg="dark blue",width=610)
        main_frame.pack()
        
        
        img_chat=Image.open("chat.jpg")
        img_chat=img_chat.resize((200,70),)
        self.photoimg=ImageTk.PhotoImage(img_chat)
        
        Title_label=Label(main_frame,bd=3,relief=RAISED,anchor="nw",width=730,compound=LEFT,image=self.photoimg,text="CHAT ME",font=("arial",30,"bold"),fg="green",bg="white")
        Title_label.pack(side=TOP)
        
        self.scroll_y=ttk.Scrollbar(main_frame,orient=VERTICAL)
        self.text=Text(main_frame,width=65,height=20,bd=3,relief=RAISED,font=("arial",14),yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT,fill=Y)
        self.text.pack()
        
        btn_frame=Frame(self.root,bd=4,bg="white",width=730)
        btn_frame.pack()
        
        label_1=Label(btn_frame,text="Type Something",font=("arial",14,"bold"),fg="green",bg="white")
        label_1.grid(row=0,column=0,padx=5,sticky=W)
        
        self.entry=StringVar()
        self.entry1=ttk.Entry(btn_frame,textvariable=self.entry,width=40,font=("times new roman",16,"bold"))
        self.entry1.grid(row=0,column=1,padx=5,sticky=W)
        
        self.send=Button(btn_frame,text="Send>>",command=self.send,font=("arial",13,"bold"),width=8,bg="green")
        self.send.grid(row=0,column=2,padx=5,sticky=W)
        
        self.clear=Button(btn_frame,text="Clear Data",command=self.clear,font=("arial",13,"bold"),width=8,bg="red",fg="white")
        self.clear.grid(row=1,column=0,padx=5,sticky=W)
        
        self.msg=" "
        self.label_2=Label(btn_frame,text=self.msg,font=("arial",14,"bold"),fg="red",bg="white")
        self.label_2.grid(row=1,column=2,padx=5,sticky=W)
        
        
        
    #=============Function Declaration===========    
    
    def enter_func(self,event):
        self.send.invoke()
        self.entry.set(" ")
    
    def clear(self):
        self.text.delete("1.0",END)
        self.entry.set('')
    
    
    def send(self):
        send="\t\t\t"+"You: "+self.entry.get()
        self.text.insert(END,"\n"+send)
        self.text.yview(END) 
        
        if (self.entry.get()==" "):
            self.msg='Please enter some input'
            self.label_2.config(text=self.msg,fg="red")
        else:
            self.msg=" "
            self.label_2.config(text=self.msg,fg="red")
        if (self.entry.get()=="hello"):
            self.text.insert(END,"\n\n"+"Bot: Hi")
                  
        elif (self.entry.get()==" Hi"):
            self.text.insert(END,"\n\n"+"Bot: Hello")
            
        elif (self.entry.get()==" I need your help"):
            self.text.insert(END,"\n\n"+"Bot: How can I help you?")
    
        elif (self.entry.get()==" How to train data?"):
            self.text.insert(END,"\n\n"+"Bot: Please click on train data button and train data process start train ?")
            
        elif (self.entry.get()==" I cann't scan my face guide me how to do?"):
            self.text.insert(END,"\n\n"+"Bot: Please ga on face detect button to scan your face and make sure you have good source of light") 
            
        elif (self.entry.get()==" How to check attendance"):
            self.text.insert(END,"\n\n"+"Bot: Go on attendance icon there you can see attendance and also you can generate report")       
        else:
            self.text.insert(END,"\n\n"+"Bot: Sorry I didn't get it")
    
if __name__=="__main__":
     root=Tk()
     obj=ChatBot(root)
     root.mainloop()
    